/**
 * 
 */
package hivis.data;

/**
 * @author O. J. Coleman
 */
public enum DataTableChange {
	SeriesAdded,
	SeriesRemoved,
	SeriesReordered
}
