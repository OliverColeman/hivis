/**
 * 
 */
package hivis.data;

/**
 * @author O. J. Coleman
 */
public enum DataSeriesChange {
	ValuesChanged,
	ValuesAdded,
	ValuesRemoved,
	LabelChanged
}
