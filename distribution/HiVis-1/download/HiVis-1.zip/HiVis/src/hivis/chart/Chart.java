package hivis.chart;

/**
 * Base class for chart implementations. Binds a DataTable to the chart and provides 
 * 
 * @author O. J. Coleman
 */
public class Chart {

}
